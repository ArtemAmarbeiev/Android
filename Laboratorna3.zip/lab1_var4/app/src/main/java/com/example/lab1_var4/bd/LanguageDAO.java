package com.example.lab1_var4.bd;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface LanguageDAO {

    @Insert
    void insert(Language language);

    @Query("SELECT name FROM language")
    List<String> getAll();

    @Query("SELECT EXISTS(SELECT * FROM language)")
    boolean isExists();
}
