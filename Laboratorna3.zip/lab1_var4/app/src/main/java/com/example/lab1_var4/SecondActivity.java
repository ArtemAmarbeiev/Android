package com.example.lab1_var4;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.lab1_var4.bd.App;
import com.example.lab1_var4.bd.AppDatabase;
import com.example.lab1_var4.bd.LanguageDAO;

public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.second_activity);
        ListView listView = findViewById(R.id.listView);
        AppDatabase db = App.getInstance().getDatabase();
        LanguageDAO languageDAO = db.languageDAO();
        String[] languages = languageDAO.getAll().toArray(new String[0]);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, languages);

        listView.setAdapter(adapter);
    }
}
