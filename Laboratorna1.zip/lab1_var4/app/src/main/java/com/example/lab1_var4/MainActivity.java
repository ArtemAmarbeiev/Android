package com.example.lab1_var4;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Spinner spinner;
    String selected;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button okButton = findViewById(R.id.okButton);
        Button cancelButton = findViewById(R.id.cancelButton);
        TextView textView = findViewById(R.id.textView);
        spinner = findViewById(R.id.spinner);
        selected = spinner.getSelectedItem().toString();

        okButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                update();
                textView.setText(selected);
            }
        });

        cancelButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                textView.setText("");
            }
        });
    }

    private void update() {
        selected = spinner.getSelectedItem().toString();
    }

}